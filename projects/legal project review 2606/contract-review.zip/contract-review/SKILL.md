---
name: contract-review
description: 合同审查工具。在合同正式发起审批前，对合同文件进行快速预审。自动识别合同模板来源（我方/对方模板），结合用户选择的审查清单和补充审查事项，调用预审接口执行审查，输出风险摘要报告并附线上审查结果链接。触发条件：用户上传合同文件、提到合同审查/审核/风险检查/合同预审，或在预审入口上传合同文件。
appkey: com.sankuai.raptor.iconfont.websdk
tags: 合同,法务,审查,预审
visibility: public

skill-dependencies:
  mtsso-skills-official:
    user_access_token_placeholder: ${user_access_token}
    audience:
      - com.sankuai.raptor.iconfont.websdk  
    prompt: 本技能所需的 token 占位符，请参考 mtsso-skills-official 的相关说明进行获取和注入

metadata:
  skillhub.creator: "caoying28"
  skillhub.updater: "yangzhihuan"
  skillhub.version: "V21"
  skillhub.source: "FRIDAY Skillhub"
  skillhub.skill_id: "6147"
  skillhub.high_sensitive: "false"
---

# 合同审查

在合同正式发起审批前，对合同进行快速风险预审。审查执行由后端完成，Skill 负责收集输入、调用接口、输出结果。

---

## 🚀 触发规范（面向调用方 Agent）

当用户消息中满足以下**任意一条**时，必须**立即**触发本 skill，无需等待用户追加指令：

1. 消息包含大象文件链接（域名含 `file.vip.neixin.cn`）
2. 消息前缀含系统提示「当前内容包含文件链接」
3. 消息内容为 `.docx` / `.pdf` / `.doc` 文件的下载链接

⚠️ **收到文件即视为发起审查请求，禁止等待用户再次确认「开始审查」才启动流程。**

---

## ⛔ 执行纪律

1. **强制等待确认**：步骤④选择审查清单时，必须展示全部清单并等待用户选择后才能继续；用户必须至少选择一个清单才能进入下一步
2. **合并一条消息**：最终结果用 `message(action=send, channel=daxiang)` 将摘要与链接**合并为同一条消息**发出，禁止分两条
3. **日志打点必须执行**：步骤①和步骤⑧均为强制步骤，失败不阻断主流程
4. **禁止暴露内部过程**：接口调用、日志打点等不得出现在回复中

---

## 前置：确保 CLI 最新

```bash
npm install -g @cap/skills-legal@latest --registry=http://r.npm.sankuai.com
```

---

## 工作流

> ⚠️ 每次收到合同文件必须从步骤⓪重新执行，禁止跳步。

```
用户上传合同文件
    ▼
⓪ SSO 认证（官方标准注入）
    → 平台已自动注入 ${user_access_token}（用户身份票），无需手动换票
    → SSO Cookie 构造：039147573f_ssoid=${user_access_token}
    → token 由平台缓存并自动刷新，无需处理过期逻辑
    ▼
① 日志打点-开始（异步，失败不阻断）
    traceId = {毫秒时间戳}_{mis}，全局保存
    skills-legal contract-review saveLog --mis <mis> --phase start
    ▼
② 文件上传（read references/common/file_upload_spec.md）
    ⚠️ CLI uploadFile 已知损坏，禁止使用
    → 优先：浏览器 fetch（agent-browser eval，适用所有沙箱）
    → 备用：curl -H "Cookie: 039147573f_ssoid=${user_access_token}"（若返回 302/SSO 重定向，立即切换浏览器 fetch）
    → 保存 s3UUID + downLoadUrl + fileName
    ▼
③ 模板识别（read references/common/template_identify_spec.md）
    → templateCode 非空：⏸️ 告知用户识别结果，等待确认（我方/有误/对方 三选一）
    → templateCode 为空或失败：⏸️ 告知已标记对方模板，允许用户更正
    ▼
④ ⏸️ 选择审查清单（read references/common/checklist_query_spec.md）
    ⚠️ 禁止使用 CLI queryRules 获取清单列表（已知只返回「我的」清单，结果不完整）
    → 必须通过 curl/fetch 直接调用 /checklist/query 接口（listType=CUSTOM, pageSize=50）
    → 展示通用清单（id=1）+ 全部自定义清单（不得截断），等待用户选择
    → 通用清单与自定义清单地位相同，均可自由选择和叠加
    → 用户必须至少选择一个清单，否则无法提交
    ▼
⑤ ⏸️ 补充审查事项（可跳过，read references/common/interaction_templates.md）
    ▼
⑥ 提交预审 + 轮询结果（read references/common/pre_review_submit_spec.md）
    ⚠️ preAuditSubmit 必须用浏览器 fetch，沙箱 curl 调用始终 404
    → 用 agent-browser eval 在 contract.sankuai.com 页面内执行 fetch 调用
    → 提交成功后立刻发一条"审查中"消息（格式见 output_spec_pre_review.md），再开始轮询
    ▼
⑦ 输出结果（read references/common/output_spec_pre_review.md）
    ▼
⑧ 日志打点-结束（异步，失败不阻断）
    skills-legal contract-review saveLog --mis <mis> --phase end \
      --trace-id <traceId> --input-file-s3 <s3uuid> --input-file-name <fileName> \
      --audit-way PRE_AUDIT --diff-tokens 0
```

---

## 文件索引

| 文件 | 用途 |
|------|------|
| `references/common/sso_spec.md` | SSO 认证规范 |
| `references/common/file_upload_spec.md` | 文件上传接口规范（含 curl 兜底方案） |
| `references/common/template_identify_spec.md` | 模板识别异步任务接口规范 |
| `references/common/template_search_spec.md` | 我方模板搜索规范（用户手动更正时） |
| `references/common/checklist_query_spec.md` | 审查清单查询规范 |
| `references/common/pre_review_submit_spec.md` | 预审提交 + 结果轮询接口规范 |
| `references/common/interaction_templates.md` | 各步骤对话话术模板 |
| `references/common/output_spec_pre_review.md` | 结果输出格式规范 |
